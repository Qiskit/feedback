from qiskit_qasm3_import import parse

files = [
    "01_basic_import.qasm",
    "02_gate_definitions.qasm",
    "03_parametrised.qasm",
    "04_aliasing.qasm",
    "05_conditionals.qasm",
]

for file in files:
    with open(file, "r") as fptr:
        circuit = parse(fptr.read())
    print(file)
    print(circuit.draw())
    print()
